package ArbolBins;

public class nodoB {
	int dato,fe;
	nodoB hi,hd;
	public nodoB(int d)
	{
		this.dato=d;
		this.fe=0;
		this.hi=null;
		this.hd=null;
		
	}

}
