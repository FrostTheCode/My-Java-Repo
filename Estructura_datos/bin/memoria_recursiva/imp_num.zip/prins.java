package memoria_recursiva;

public class prins {

	public static void main(String[] args) {
		recursividad r=new recursividad();
		r.imp(1);

	}

}
