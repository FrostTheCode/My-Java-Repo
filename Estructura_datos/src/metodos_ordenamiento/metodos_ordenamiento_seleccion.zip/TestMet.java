package metodos_ordenamiento;

public class TestMet {

	public static void main(String[] args) {
		MetOrd or=new MetOrd();
		int [] a= {4,3,7,-125,265,7854,215,-1256};
		or.ordsel(a);
		or.imp(a);

	}

}
