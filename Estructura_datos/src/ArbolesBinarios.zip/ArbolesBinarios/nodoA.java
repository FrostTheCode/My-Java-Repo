package ArbolesBinarios;

public class nodoA {
	int dat;
	//String name;
	public nodoA hiji,hijd;
	public nodoA (int d)
	{
		this.dat=d;
		//this.name=nom;
		this.hijd=null;
		this.hiji=null;
	}
	public String toString()
	{
		return "su Dato es "+dat;
	}

}
