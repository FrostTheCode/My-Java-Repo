package Shell_alg;

public class principal {

	public static void main(String[] args) {
		alg g=new alg();
		int v1[]= {5,6,3,44,22,1};
		int v2[]= {55,4,43,44,2,10,4567,45638};
		int v3[]= {5,2,1,8,3,9,7};
		
		System.out.println("Arreglo Original");
		g.mosAr(v3);
		g.shell(v3);
		g.radi(v3);
		g.quic(v3, 0, v3.length-1);
		

	}

}
